exports.handler = (event, context) => {
    // TODO implement
    const response = 'ERROR: This is not an actual lambda handler. Your installation is broken. Fix by running the setup profile via the tf-modules or by building the stac-server source either manually or through your operations repository.';
    context.fail(response);
  };
